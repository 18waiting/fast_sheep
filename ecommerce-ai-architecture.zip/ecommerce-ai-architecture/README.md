# 电商商家 AI 客服 · 架构图集

入口：[index.html](index.html)

根据用户提供的《电商商家 AI 客服系统完整架构设计》整理为六个主题、七张图（5 张 architecture、2 张 sequence）。**这是文档对应的逻辑设计，不是对实际代码或生产部署的确认。**

## 图表目录与来源

| 图 | 视角 | 主要章节 |
|---|---|---|
| [01](./01-system-overview.html) | 系统总览 | §1–10、§18–28、§40、§64、§68 |
| [02](./02-ai-knowledge-data.html) | AI、知识与实时数据 | §11–17、§33、§53、§58–59 |
| [03A](./03a-refund-decision.html) | 退款决策与消费者确认 | §18–21、§46 |
| [03B](./03b-refund-execution.html) | 退款执行、验证与留痕 | §20–23、§46 |
| [04](./04-tenant-security.html) | 多租户与集成安全 | §5–6、§17、§40–44 |
| [05](./05-merchant-human.html) | 商家管理与人工协同 | §24–26、§29–33、§48、§62、§65 |
| [06](./06-events-quality.html) | 事件驱动与质量迭代 | §34–39、§59–63 |

## 阅读顺序与使用

1. 先打开 `index.html`，从图 01 了解总流程。
2. 用图 02、04 核对能力分工和安全边界；退款完整链路依次看 03A、03B。
3. 图 05 面向商家配置与客服协同；图 06 面向事件处理与质量迭代。
4. 每张 HTML 可独立在浏览器打开，无需启动项目、配置 API Key 或安装前端依赖。导航页缩略图需保留同目录 PNG。
5. 浏览器里可切换浅/深色、缩放、搜索、聚焦节点；导出菜单位于右上角。当前图是静态模式，未启用 WebM 动画。
6. 若需修改，编辑相应 `.architecture.json` / `.sequence.json`，重新 validate、deliver、visual-check；不要直接修改生成的 HTML。

## 不能在读图时丢失的边界

- **LLM / Decision ≠ Policy**：模型理解和表达，Decision 产出信号，Policy 决定 ALLOW、DENY、REQUIRE_CONFIRMATION、REQUIRE_HUMAN。
- **RAG ≠ 实时交易数据**：RAG 保存商家知识与政策解释；订单、支付、退款、库存等经 Commerce API 读取。
- **受理 ≠ 成功**：退款先核验身份和政策、确认提案，再重查状态、幂等执行、查询真实结果、记录 Action Ledger。
- **多租户与归属在 API 层校验**，不是交给提示词自律；应用层、数据行、向量空间分别隔离。
- **凭证不进入模型上下文**；集成层只持有 credential_ref，受控获取 Secret Manager 中的密钥。
- **人工审核不绕过系统安全链**；消费者明确要求人工时立即接管。
- **自动评估不等于自动改政策**：低分复核和配置变更保留人的控制权。

## 展示聚合、省略与推导

- 图 01 将 Decision / RAG / Commerce 合并成“判断、知识与事实”；图 02 再拆开。只读问答绕过 Action，查询结果的返回箭头和渠道回程省略。
- 图 03A / 03B 的支付工作流包含对 Decision 信号的使用；“幂等与账本”仅为逻辑聚合，并不要求同一个数据库。金额 $49、$100 为原文案例，不是通用退款规则。
- 图 04 把 Policy + Action 汇总为“授权后的安全写入”，以突出读写隔离。读、写适配都取凭证，图中只绘制一个代表性的取密钥连接；不代表只读无需凭证。
- 图 05 将配置模型、版本留存、onboarding 测试与运行权限按治理关系排列；不是原文指定的独立部署流水线。
- 图 06 上半部是事件链，下半部是质量链；运行时对采样记录的写入和新配置回流未画成跨全图的回线。发布前评测为对原文测试、人工复核和版本更新的整理，并不指定新的 CI/CD 产品。
- 所有节点默认代表逻辑模块。文档 §49 允许早期模块化单体（Modular Monolith），本图集未推定 Kubernetes、云区域、实例数、网络 CIDR 或具体 SLA。
- 事件总线的 Kafka / SQS / PubSub / RabbitMQ 是选项，不是同时部署四套。
- 本图集按关键路径取舍，并非逐节点穷尽 68 节：详细 ERD、实体字段、图片理解、模型路由、存储选型和具体云部署需结合实现另行展开。

## 数据与实施范围补充（原文 §36–39、§49–54、§66）

| 职责 | 文档建议 |
|---|---|
| 结构化业务 / 配置 / 审计 | PostgreSQL；租户数据范围、版本和历史记录 |
| 会话 / 缓存 / 限流 / 锁 / 幂等临时状态 | Redis |
| 商家知识检索 | Vector DB；不替代订单与支付数据库 |
| 文档 / 图片 / 导出文件 | Object Storage |
| 早期部署 | Modular Monolith，可保留内部模块边界 |

- **Phase 1**：Web Chat、Shopify、Knowledge RAG、商品咨询、订单/物流查询、AI 建议回复、人工转接；AI 不修改订单。
- **Phase 2**：退货、换货、取消、改址、Policy、Ledger；大部分 Action 需要人工确认。
- **Phase 3**：受限的自动退货/取消/小额退款、主动物流客服、风控信号、Evaluation。
- **Phase 4**：WhatsApp、Instagram、Email、Marketplace、语音、个性化、高级自动化等。

## 校验与限制

七张最终图均经过：
- `validate` / `deliver`：showcase 9/9，0 composition errors，0 warnings。
- `visual-check`：1440×900、1600×1000、1920×1080、2048×1320；浅色布局测量，两个端点尺寸的浅/深色截图。
- 视觉检查：逐张检查 1440×900 浅色和 2048×1320 深色截图，主图、连线、标签、图例和说明卡完整。
- 代表性交互：图 01 的搜索、聚焦、关闭详情、主题切换和导出菜单；**未逐一验证所有导出文件格式**。

结构校验、自动浏览器证据和视觉判断相互独立；自动 visual-check 的 `visualReview` 仍为 pending，人工/图像审阅结论单列于 `handoff-receipts.json`，没有改写自动回执。

`index.html` 仅为图集导航，不属于 Archify 9/9 校验对象。`revisions/first-layout/` 是过期布局留档，不是最终交付；分发压缩包不包含它。

详见 [验收记录.md](验收记录.md) 与 [handoff-receipts.json](handoff-receipts.json)。

## 来源与追溯

- 原始文件：`/Users/wb02605050/.codex/attachments/aed8e223-cb12-4b37-8dc8-7a8b6b6096eb/pasted-text.txt`
- 字节不变的副本：`/Users/wb02605050/Documents/ChatGPT/学习/ecommerce-ai-architecture/source/source-document.md`
- SHA-256：`3913d822c0de2e28b50a04205a03a5f8bac2646d188ace8ccee6545f82c19ade`
- 整理日期：2026-09-20
- 工具：本地 Archify Skill 2.17；未修改 Skill 包或联网部署业务服务。
